using Core.Utils;
using WeaponConfigNs;
public class FireShakeMath
{
}